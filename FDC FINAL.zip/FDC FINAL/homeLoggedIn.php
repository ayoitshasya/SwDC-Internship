<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FDC Appliction</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="auth.js">
</head>
<body>
    <div class="card">
        <h5 id="abc"><?php echo $_SESSION['username'] . ',';?></h5>
     <h1>WELCOME to FDC Website</h1>
     <button onclick="window.location.href='Application/View_applications.php'"type="button" id="btn1">Application for FDC Form </button>
        <button onclick="window.location.href='Reimbursement/Reimbursement_page1.php'" type="button" id="btn2">FDC reimbursement Forrm</button>
    </div>
</body>
</html>