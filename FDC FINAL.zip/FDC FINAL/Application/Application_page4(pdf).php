<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$application_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Check if application_id is valid
if ($application_id <= 0) {
    echo "Invalid application ID.";
    exit;
}

$sql = "SELECT * FROM applications WHERE application_id = $application_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $application_row = $result->fetch_assoc();
    $eid = $application_row['eid'];
    $sql = "SELECT * FROM employee WHERE eid = $eid";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $emp_row = $result->fetch_assoc();
    } else {
        echo "No records found for Employee ID: $eid";
    }
} else {
    echo "No records found for Employee ID: $eid";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FDC Application</title>
    <link rel="stylesheet" href="Application_page4(pdf).css">
    <style>
        .center {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        @media print {
            .no-print {
                display: none;
            }

            button {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div class="card">
        <div class="no-print">
            <?php
            if ($_SESSION['user_type'] == 'employee')
                echo '<h2 style="color: green;">Application Submitted successfully</h2>';
            ?>
        </div>

        <p><b>Name: <?php echo $emp_row['fname'] . ' ' . $emp_row['lname']; ?></b></p>
        <p><b>Employee ID: <?php echo $emp_row['eid']; ?></b></p>
        <p><b>Department: <?php echo $emp_row['dept']; ?></b></p>
        <p><b>Designation: <?php echo $emp_row['designation']; ?></b></p>
        <p><b>Date of Appointment: <?php echo $emp_row['date_of_appointment']; ?></b></p>
        <p><b>Date of Appointment of Present Post: <?php echo $emp_row['present_appointment']; ?></b></p>
        <p><b>Purpose of FDC: <?php echo $application_row['purpose']; ?></b></p>
        <p><b>Name and Address of Organising Institution: <?php echo $application_row['org_institution']; ?></b></p>
        <p><b>Other Supporting Organisation: <?php echo $application_row['supporting_org']; ?></b></p>
        <p><b>The program is during period <?php echo $application_row['duration_from']; ?> and <?php echo $application_row['duration_to']; ?></b></p>
        <p><b>Total Number of Days: <?php echo $application_row['total_days']; ?></b></p>
        <p><b>Last Day of Registration: <?php echo $application_row['registration_last_day']; ?></b></p>
        <p><b>Registration Fee: <?php echo $application_row['registration_fee']; ?></b></p>
        <p><b>No. of ODs required: <?php echo $application_row['ods_required']; ?></b></p>
        <p><b>Amount claimed for year <?php echo $application_row['year']; ?>: <?php echo $application_row['amount_claimed']; ?></b></p>
        <p><b>Total ODs availed for year <?php echo $application_row['od_year']; ?>: <?php echo $application_row['total_ods']; ?></b></p>
        <p><b>Load Adjustment Sheet: <a href="<?php echo $application_row['load_adjustment_path']; ?>" target="_blank">Adjustment Sheet</a></b></p>
        <p><b>Conference Brochure: <a href="<?php echo $application_row['conference_brochure_path']; ?>" target="_blank">Conference Brochure</a></b></p>
        <p><b>Email: <a href="<?php echo $application_row['email_upload_path']; ?>" target="_blank">Email Upload</a></b></p>
        <p><b>Purpose of Attending FDC: <?php echo $application_row['purpose_scope']; ?></b></p>

        <div class="center">
            <?php
            if ($_SESSION['user_type'] == 'employee') {
                echo '<button style="width: fit-content;" onclick="window.print()">Print</button>';
            } elseif ($_SESSION['user_type'] == 'HOD') {
                echo '<button onclick="window.location.href = \'HOD_Approval.php?id=' . $application_id .'\'">Next</button>';
            } elseif ($_SESSION['user_type'] == 'Principal') {
                echo '<button onclick="window.location.href = \'Principal_Approval.php?id=' . $application_id .'\'">Next</button>';
            }
            ?>
            <button onclick="window.location.href = '../homeLoggedIn.php'">Return to Home</button>

        </div>
    </div>
    <script src="Application_page6(pdf).js"></script>
</body>

</html>