<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch applications from the database
if ($_SESSION['user_type'] == 'employee') {
    $eid = $_SESSION['eid'];
    $sql = "SELECT * FROM applications where eid = $eid";
} elseif ($_SESSION['user_type'] == 'HOD') {
    $sql = "SELECT * FROM applications where status = 'Pending'";
} elseif ($_SESSION['user_type'] == 'Principal') {
    $sql = "SELECT * FROM applications where status = 'Recommended by HOD'";
}


$result = mysqli_query($conn, $sql);
$num = mysqli_num_rows($result);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FDC Application</title>
    <link rel="stylesheet" href="Application_page4(pdf).css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e5e5e5;
        }
    </style>
</head>

<body>
    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>Application ID</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($num > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $applicationId = $row['application_id'];
                        echo "<tr onclick=\"window.location.href='Application_page4(pdf).php?id=$applicationId'\">";
                        echo "<td>{$row['application_id']}</td>";
                        echo "<td>{$row['status']}</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='2'>No applications found</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <?php if ($_SESSION['user_type'] == 'employee')
            echo '<button onclick="window.location.href = \'Application_page1.php\'">New Application</button>'
        ?>
        <button onclick="window.location.href = '../homeLoggedIn.php'">Back</button>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>

</html>