<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$eid = $_SESSION['eid'];
$sql = "SELECT application_id, purpose FROM applications WHERE status = 'Approved by Principal' AND eid = $eid";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reimbursement Form</title>
    <link rel="stylesheet" href="Reimbursement_page2.css">
</head>

<body>
    <div class="card">
        <form id="signUpForm" action="Reimbursement_page3.php" method="GET" onsubmit="return validateForm();">
            <label id="lab">Select the approved application box</label><br><br>
            <div class="form-group">
                <label for="approved_application">Approved Application:<span class="asterisk">*</span></label>
                <select name="approved_application" id="approved_application" required>
                    <option value="" disabled selected>Select the approved application</option>
                    <?php
                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo '<option value="' . $row["application_id"] . '">' . $row["application_id"] . '. ' . $row["purpose"] . '</option>';
                        }
                    } else {
                        echo '<option value="" disabled>No approved applications available</option>';
                    }
                    ?>
                </select>
            </div>
            <h5>Check above details & click next to proceed further</h5>
            <input type="submit" id="button" value="Next">
        </form>
    </div>
    <script src="Reimbursement_page2.js"></script>
</body>

</html>