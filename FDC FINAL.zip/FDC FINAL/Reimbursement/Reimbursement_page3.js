function validateForm() {
    const requiredFields = document.querySelectorAll('.form-group input, .form-group select');
    let allFilled = true;
    requiredFields.forEach(field => {
        if (!field.value) {
            allFilled = false;
            field.style.border = '1px solid red';
        } else {
            field.style.border = '1px solid #a52017';
        }
    });
    if (allFilled) {
        window.location.href = 'Application_page2.html';
    } else {
        alert('Please fill all the required fields.');
    }
}

function calculateTotalDays() {
    const startDate = document.getElementById('start_date').value;
    const endDate = document.getElementById('end_date').value;

    if (startDate && endDate) {
        const fromDate = new Date(startDate);
        const toDate = new Date(endDate);

        const timeDiff = toDate - fromDate;
        const dayDiff = timeDiff / (1000 * 60 * 60 * 24) + 1; // +1 to include the start day

        if (dayDiff > 0) {
            document.getElementById('total_days').value = dayDiff;
        } else {
            alert('The end date must be after the start date.');
            document.getElementById('total_days').value = '';
        }
    }
}