<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$application_id = $_GET['id'];
$sql = "SELECT * FROM applications WHERE application_id = $application_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "No records found for Employee ID: $e_id";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reimburstment Form</title>
    <link rel="stylesheet" href="Reimbursement_page4.css">
</head>

<body>
    <div class="card">
        <form id="signUpForm">
            <label id="lab">Details of FDC facility availed, if any</label><br><br>
            <div class="form-group">
                <label for="amount_claimed">Amount claimed for the year:<span class="asterisk">*</span></label>
                <input type="number" name="amount_claimed" id="amount_claimed" class="auto" placeholder="auto-generated" value="<?php echo $row['amount_claimed'];?>" required readonly>
                <!-- <select name="year_claimed" id="year_claimed" class="year-select" value="<?php echo $row['year'];?>" required readonly>
                    <option value="" disabled selected>auto-generated</option>
                </select> -->
                <input type="number" name="year_claimed" id="year_claimed" class="auto" value="<?php echo $row['year'];?>" required readonly>
            </div>
            <div class="form-group">
                <label for="total_ods">Total ODs availed for the year:<span class="asterisk">*</span></label>
                <input type="number" name="total_ods" id="total_ods" class="auto" placeholder="auto-generated" value="<?php echo $row['total_ods'];?>" required readonly>
                <!-- <select name="year_ods" id="year_ods" class="year-select" value="<?php echo $row['od_year'];?>" required readonly>
                    <option value="" disabled selected>auto-generated</option>
                </select> -->
                <input type="number" name="year_ods" id="year_ods" class="auto" value="<?php echo $row['od_year'];?>" required readonly>
            </div>
            <h5>Check above details & click next to proceed further</h5>
            <button onclick="validateForm()" type="button" id="button">Next</button>
        </form>
    </div>
</body>
<script src="Reimbursement_page4.js"></script>

</html>