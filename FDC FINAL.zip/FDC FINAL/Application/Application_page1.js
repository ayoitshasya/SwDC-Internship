function validateForm() {
    const requiredFields = document.querySelectorAll('.form-group input');
    let allFilled = true;
    
    requiredFields.forEach(field => {
        if (!field.value) {
            allFilled = false;
            field.style.border = '1px solid red';
        } else {
            field.style.border = '1px solid #a52017';
        }
    });
    
    if (allFilled) {
        window.location.href = 'Application_page2.php';
    } else {
        alert('Please fill all the required fields.');
    }
}

document.getElementById('button').addEventListener('click', validateForm);
