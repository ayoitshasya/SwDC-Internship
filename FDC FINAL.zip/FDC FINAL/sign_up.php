<?php
session_start();
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //Retrieve the form data
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $eid = $_POST["e_id"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $dept = $_POST["dept"];
    $designation = $_POST["designation"];
    $date_of_appointment = $_POST["date_of_appointment"];
    $present_appointment = $_POST["present_appointment"];
    // Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO employee (eid, fname, lname, email, password, dept, designation, date_of_appointment, present_appointment, user_type) VALUES ('$eid', '$fname', '$lname', '$email', '$hashed_password', '$dept', '$designation', '$date_of_appointment', '$present_appointment', 'employee')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Account Created successfully.');</script>";
        header("Refresh: 0, URL=index.html");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FDC Application</title>
    <link rel="stylesheet" href="sign_up.css">
</head>

<body>
    <div class="card">
        <form id="signUpForm" action="sign_up.php" method="post" onsubmit="return validateForm()">
            <label id="lab">Sign-Up</label><br><br>

            <div class="name-container">
                <div>
                    <label for="fname">First Name:<span class="asterisk">*</span></label><br>
                    <input type="text" name="fname" id="fname" placeholder="Enter your First Name" required>
                    <span id="fname_error" class="error-message"></span>
                </div>
                <div>
                    <label for="lname">Last Name:<span class="asterisk">*</span></label><br>
                    <input type="text" name="lname" id="lname" placeholder="Enter your Last Name" required>
                    <span id="lname_error" class="error-message"></span>
                </div>
            </div><br>

            <label for="e_id">Employee ID:<span class="asterisk">*</span></label><br>
            <input type="text" name="e_id" id="e_id" placeholder="Enter your Employee Id" required>
            <span id="e_id_error" class="error-message"></span><br>

            <label for="email">Email:<span class="asterisk">*</span></label><br>
            <input type="email" name="email" id="email" placeholder="Enter your Email" required>
            <span id="email_error" class="error-message"></span><br>

            <label for="password">Password:<span class="asterisk">*</span></label><br>
            <input type="password" name="password" id="password" placeholder="Enter your Password" required>
            <span id="password_error" class="error-message"></span><br>

            <label for="dept">Department:<span class="asterisk">*</span></label><br>
            <select name="dept" id="dept" required>
                <option value="">Select your Department</option>
                <option value="COMPS">COMPS</option>
                <option value="IT">IT</option>
                <option value="EXTC">EXTC</option>
                <option value="MECH">MECH</option>
                <option value="ETRX">ETRX</option>
                <option value="SAH">SAH</option>
            </select><br><br>

            <label for="designation">Designation:<span class="asterisk">*</span></label><br>
            <input type="text" name="designation" id="designation" placeholder="Enter your Designation" required>
            <span id="designation_error" class="error-message"></span><br>

            <label for="date_of_appointment">Date of Appointment (SVU):<span class="asterisk">*</span></label><br>
            <input type="date" name="date_of_appointment" id="date_of_appointment" required>
            <span id="date_of_appointment_error" class="error-message"></span><br>

            <label for="present_appointment">Date of appointment on the present post:<span class="asterisk">*</span></label><br>
            <input type="date" name="present_appointment" id="present_appointment" required>
            <span id="present_appointment_error" class="error-message"></span><br>

            <h5>Check above details & click next to proceed further</h5>
            <button type="submit" id="button">Next</button>
        </form>
    </div>
    <script src="sign_up.js"></script>
</body>

</html>