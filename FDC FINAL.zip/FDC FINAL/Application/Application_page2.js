function validateForm() {
    const requiredFields = document.querySelectorAll('.form-group input, .form-group select');
    let allFilled = true;
    requiredFields.forEach(field => {
        if (!field.value) {
            allFilled = false;
            field.style.border = '1px solid red';
        } else {
            field.style.border = '1px solid #a52017';
        }
    });
    // if (allFilled) {
    //     window.location.href = 'Application_page2.html';
    // } else {
    //     alert('Please fill all the required fields.');
    // }
}

function checkOtherOption() {
    const purposeSelect = document.getElementById('purpose');
    const otherPurposeInput = document.getElementById('otherPurpose');
    if (purposeSelect.value === 'Other') {
        otherPurposeInput.style.display = 'inline';
    } else {
        otherPurposeInput.style.display = 'none';
    }
}

document.getElementById('duration_from').addEventListener('change', calculateTotalDays);
document.getElementById('duration_to').addEventListener('change', calculateTotalDays);

function calculateTotalDays() {
    const durationFrom = document.getElementById('duration_from').value;
    const durationTo = document.getElementById('duration_to').value;

    if (durationFrom && durationTo) {
        const fromDate = new Date(durationFrom);
        const toDate = new Date(durationTo);

        if (fromDate >= toDate) {
            alert('The end date must be after the start date.');
            document.getElementById('total_days').value = '';
        } else {
            const timeDiff = toDate - fromDate;
            const dayDiff = timeDiff / (1000 * 60 * 60 * 24) + 1; // +1 to include the start day
            document.getElementById('total_days').value = dayDiff;
        }
    }
}
