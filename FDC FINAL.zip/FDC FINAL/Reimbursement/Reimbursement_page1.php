<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$eid = $_SESSION['eid'];
$sql = "SELECT * FROM employee WHERE eid = $eid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $dept = $row['dept'];
    $designation = $row['designation'];
    $date_of_appointment = $row['date_of_appointment'];
    $present_appointment = $row['present_appointment'];
} else {
    echo "No records found for Employee ID: $e_id";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reimbursement Form</title>
    <link rel="stylesheet" href="Reimbursement_page1.css">
</head>

<body>
    <div class="card">
        <form id="signUpForm">
            <label id="lab">FDC Reimbursement Form</label><br><br>
            <div class="form-group">
                <label for="name">Name:<span class="asterisk">*</span></label>
                <input type="text" name="name" id="name" value="<?php echo $_SESSION['username']; ?>" required readonly>
            </div>
            <div class="form-group">
                <label for="e_id">Employee ID:<span class="asterisk">*</span></label>
                <input type="text" name="e_id" id="e_id" value="<?php echo $_SESSION['eid']; ?>" required readonly>
            </div>
            <div class="form-group">
                <label for="dept">Department:<span class="asterisk">*</span></label>
                <input type="text" name="dept" id="dept" value="<?php echo $dept; ?>" required readonly>
            </div>
            <div class="form-group">
                <label for="designation">Designation:<span class="asterisk">*</span></label>
                <input type="text" name="designation" id="designation" value="<?php echo $designation; ?>" required readonly>
            </div>
            <div class="form-group">
                <label for="date_of_appointment">Date of Appointment:<span class="asterisk">*</span></label>
                <input type="date" name="date_of_appointment" id="date_of_appointment" value="<?php echo $date_of_appointment; ?>" required readonly>
            </div>
            <div class="form-group">
                <label for="present_appointment">Date of appointment on the present post:<span class="asterisk">*</span></label>
                <input type="date" name="present_appointment" id="present_appointment" value="<?php echo $present_appointment; ?>" required readonly>
            </div>

            <h5>Check above details & click next to proceed further</h5>
            <div class="form-group">
                <input type="checkbox" id="details_checked" required>
                <label for="details_checked">I have checked the above details</label>
            </div>
            <div class="center">
                <button onclick="validateForm()" type="button" id="button">Next</button>
            </div>
        </form>
    </div>
    <script src="Reimbursement_page1.js"></script>
</body>

</html>