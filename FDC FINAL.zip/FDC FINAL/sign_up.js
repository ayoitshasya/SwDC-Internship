function displayError(elementId, message) {
    document.getElementById(elementId).innerText = message;
}

function clearErrorMessages() {
    document.querySelectorAll('.error-message').forEach(el => el.innerText = "");
}

function validateForm() {
    clearErrorMessages();
    
    var isValid = true;

    var e_id = document.getElementById("e_id").value;
    if (!/^\d+$/.test(e_id)) {
        displayError("e_id_error", "Employee ID must contain numbers only.");
        isValid = false;
    }

    var email = document.getElementById("email").value;
    if (!email.endsWith("@somaiya.edu")) {
        displayError("email_error", "Login with only somaiya account.");
        isValid = false;
    }

    var password = document.getElementById("password").value;
    var passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(password)) {
        displayError("password_error", "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.");
        isValid = false;
    }

    var dateOfAppointment = document.getElementById("date_of_appointment").value;
    var presentAppointment = document.getElementById("present_appointment").value;

    if (new Date(presentAppointment) < new Date(dateOfAppointment)) {
        displayError("present_appointment_error", "Date of appointment on the present post should be greater than or equal to Date of Appointment (SVU).");
        isValid = false;
    }

    return isValid;
}
5