document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('form').addEventListener('submit', validateSignUpForm);
});

function validateSignUpForm(event) {
    const name = document.getElementById("name").value;
    const e_id = document.getElementById("e_id").value;
    const password = document.getElementById("password").value;
    const dept = document.getElementById("dept").value;
    const designation = document.getElementById("designation").value;
    const date_of_appointment = document.getElementById("date_of_appointment").value;
    const present_appointment = document.getElementById("present_appointment").value;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (name === "") {
        alert("Name must be filled out");
        event.preventDefault();
        return false;
    }
    if (e_id === "") {
        alert("Employee ID must be filled out");
        event.preventDefault();
        return false;
    }
    if (!/^[a-zA-Z0-9]+$/.test(e_id)) {
        alert("Employee ID must not contain special characters");
        event.preventDefault();
        return false;
    }
    if (password === "") {
        alert("Password must be filled out");
        event.preventDefault();
        return false;
    }
    if (password.length < 8) {
        alert("Password must be at least 8 characters long");
        event.preventDefault();
        return false;
    }
    if (!passwordRegex.test(password)) {
        alert("Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character");
        event.preventDefault();
        return false;
    }
    if (dept === "") {
        alert("Department must be filled out");
        event.preventDefault();
        return false;
    }
    if (designation === "") {
        alert("Designation must be filled out");
        event.preventDefault();
        return false;
    }
    if (date_of_appointment === "") {
        alert("Date of Appointment (SVU) must be filled out");
        event.preventDefault();
        return false;
    }
    if (present_appointment === "") {
        alert("Date of appointment on the present post must be filled out");
        event.preventDefault();
        return false;
    }

    return true;
}
