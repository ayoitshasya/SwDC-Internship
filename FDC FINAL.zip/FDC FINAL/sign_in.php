<?php
// require_once 'vendor/autoload.php';

// $clientID = '135824938359-0vcna5pdb0tcja47vge9husso923lmt3.apps.googleusercontent.com';
// $clientSecret = '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';
// $redirectUri = 'http://localhost/fdc_website/pagee_look.html';

// $client = new Google_Client();
// $client->setClientId($clientID);
// $client->setClientSecret($clientSecret);
// $client->setRedirectUri($redirectUri);
// $client->addScope("email");
// $client->addScope("profile");


// if (isset($_GET['code'])) {
//     $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
//     $client->setAccessToken($token['access_token']);

//     $google_oauth = new Google_Service_Oauth2($client);
//     $google_account_info = $google_oauth->userinfo->get();
//     $email = $google_account_info->email;
//     $name = $google_account_info->name;

//     header("Location:sign_in.php");
//     exit();
// }

session_start();
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

// $_SESSION["isAdmin"] = false;
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $eid = $_POST["e_id"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM employee WHERE eid='$eid'";
    $result = $conn->query($sql);
    $num = mysqli_num_rows($result);

    if ($num == 1) {
        while ($row = mysqli_fetch_assoc($result)) {
            if (password_verify($password, $row['password'])) {
                $_SESSION['loggedIn'] = true;
                $_SESSION['username'] = $row['fname'].' '. $row['lname'];
                $_SESSION['eid'] = $eid;
                $_SESSION['user_type'] = $row['user_type'];
                header('location: homeLoggedIn.php');
            } else {
                $showErrorAlert = "Invalid Credentials";
            }
        }
    } else {
        $showErrorAlert = "Invalid Credentials";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FDC Application</title>
    <link rel="stylesheet" href="styles.css">
    <script src="sign_in.js" defer></script>
</head>

<body>
    <div class="card1">
        <form action="sign_in.php" method="POST" onsubmit="return validateSignInForm()">
            <label id="lab">Sign-In</label><br><br>
            <label>Employee ID:</label><br>
            <input type="text" name="e_id" id="e_id" placeholder="Enter your Employee Id"><br><br>
            <label>Password:</label><br>
            <input type="password" name="password" id="password" placeholder="Enter your Password"><br><br>
            <input type="submit" id="button" value="Sign In">
            <button onclick="window.location.href='<?php echo $client->createAuthUrl(); ?>'" type="button" name="button" id="button">Sign-in with Google</button>
        </form>
    </div>
</body>

</html>