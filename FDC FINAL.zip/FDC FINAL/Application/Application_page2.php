<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["purpose"] != "Other")
        $_SESSION["purpose"] = $_POST["purpose"];
    else
        $_SESSION["purpose"] = $_POST["otherPurpose"];

    $_SESSION["org_institution"] = $_POST["org_institution"];
    $_SESSION["supporting_org"] = $_POST["supporting_org"];
    $_SESSION["duration_from"] = $_POST["duration_from"];
    $_SESSION["duration_to"] = $_POST["duration_to"];
    $_SESSION["total_days"] = $_POST["total_days"];
    $_SESSION["registration_last_day"] = $_POST["registration_last_day"];
    $_SESSION["registration_fee"] = $_POST["registration_fee"];
    $_SESSION["vacation_period"] = $_POST["vacation_period"];
    $_SESSION["ods_required"] = $_POST["ods_required"];
    header("location: Application_page3.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FDC Application</title>
    <link rel="stylesheet" href="Application_page2.css">
</head>

<body>
    <div class="card">
        <form id="signUpForm" action="Application_page2.php" method="post" onsubmit="return validateForm()">
            <label id="lab">Details about STTPS/Symposium/Workshop/Conference/Seminar</label><br><br>
            <div class="form-group">
                <label for="purpose">Select purpose for FDC:<span class="asterisk">*</span></label>
                <select id="purpose" name="purpose" onchange="checkOtherOption()">
                    <option value="STTP">STTP</option>
                    <option value="Symposium">Symposium</option>
                    <option value="Workshop">Workshop</option>
                    <option value="Conference">Conference</option>
                    <option value="Other">Other</option>
                </select>
                <input type="text" id="otherPurpose" name="otherPurpose" placeholder="Specify other purpose" style="display:none;">
            </div>
            <div class="form-group">
                <label for="org_institution">Name and address of organising Institution:<span class="asterisk">*</span></label>
                <input type="text" name="org_institution" id="org_institution" placeholder="Enter the name and address of the organising institution" required>
            </div>
            <div class="form-group">
                <label for="supporting_org">Other supporting organization worth mentioning (e.g., EEE/SAE etc):<span class="asterisk">*</span></label>
                <input type="text" name="supporting_org" id="supporting_org" placeholder="Enter supporting organization" required>
            </div>
            <div class="form-group">
                <label for="duration_from">Date and duration from:<span class="asterisk">*</span></label>
                <input type="date" name="duration_from" id="duration_from" class="small-input" required>
                <span style="margin: 0 10px;"> to </span>
                <input type="date" name="duration_to" id="duration_to" class="small-input" required>
            </div>
            <div class="form-group">
                <label for="total_days">Total number of days:<span class="asterisk">*</span></label>
                <input type="number" name="total_days" id="total_days" class="small-input" readonly required>
                <label for="registration_last_day" style="margin-left: 10px;">Last day of registration:<span class="asterisk">*</span></label>
                <input type="date" name="registration_last_day" id="registration_last_day" class="small-input" required>
            </div>
            <div class="form-group">
                <label for="registration_fee">Registration Fee:<span class="asterisk">*</span></label>
                <input type="number" name="registration_fee" id="registration_fee" placeholder="Enter registration fee" min="0" required>
            </div>
            <div class="form-group">
                <label for="vacation_period">The program is during Vacation/non-vacation period:<span class="asterisk">*</span></label>
                <select id="vacation_period" name="vacation_period" required>
                    <option value="Vacation">Vacation</option>
                    <option value="Non-vacation">Non-vacation</option>
                </select>
            </div>
            <div class="form-group">
                <label for="ods_required">No. of ODs required:<span class="asterisk">*</span></label>
                <select id="ods_required" name="ods_required" required>
                    <option value="0">0</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                </select>
            </div>

            <h5>Check above details & click next to proceed further</h5>
            <input type="submit" id="button" value="Next"></input>
        </form>
    </div>
    <script src="Application_page2.js"></script>
</body>

</html>