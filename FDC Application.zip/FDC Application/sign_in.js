document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('form').addEventListener('submit', validateSignInForm);
});

function validateSignInForm(event) {
    const e_id = document.getElementById("e_id").value;
    const password = document.getElementById("password").value;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (e_id === "") {
        alert("Employee ID must be filled out");
        event.preventDefault();
        return false;
    }
    if (!/^[a-zA-Z0-9]+$/.test(e_id)) {
        alert("Employee ID must not contain special characters");
        event.preventDefault();
        return false;
    }
    if (password === "") {
        alert("Password must be filled out");
        event.preventDefault();
        return false;
    }
    if (password.length < 8) {
        alert("Password must be at least 8 characters long");
        event.preventDefault();
        return false;
    }
    if (!passwordRegex.test(password)) {
        alert("Password must contain at least one uppercase letter, one lowercase letter, one digit, and one special character");
        event.preventDefault();
        return false;
    }

    return true;
}
