
    // var Name=document.getElementById("name").value;
    var Employee_id=document.getElementById("e_id").value; 
    var Password=document.getElementById("password").value; 
    // var Department=document.getElementById("dept").value; 
    // var Designation=document.getElementById("designation").value; 
    // var Date_of_Appointment=document.getElementById("date_of_appointment").value; 
    // var Date_of_appointment_on_the_present_pos=document.getElementById("present_appointment").value; 

    var btn1=document.getElementById("btn1").value;
    var btn2=document.getElementById("btn2").value;

  


    
