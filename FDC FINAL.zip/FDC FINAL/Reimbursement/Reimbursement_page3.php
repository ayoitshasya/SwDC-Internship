<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

function uploadFile($input_name, $application_id)
{
    $file_name = $_FILES[$input_name]["name"];
    $file_tmp = $_FILES[$input_name]["tmp_name"];

    //renaming file uniquely for each user
    $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
    $upload_file = 'PK_' . $application_id . '_' . $input_name . '.' . $file_extension;
    $upload_dir = "../uploads/Reimbursements/";

    // Move uploaded file to desired location
    if (move_uploaded_file($file_tmp, $upload_dir . $upload_file)) {
        return '../uploads/Reimbursements/' . $upload_file;
    }
    return NULL;
}

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $application_id = $_POST['application_id'];
    $registration_amount = $_POST['registration_amount'];
    $ta_amount = $_POST['ta_amount'];
    $da_amount = $_POST['da_amount'];
    $attachments_path = uploadFile('attachments', $application_id);

    $sql = "INSERT INTO reimbursements(application_id, registration_amount, ta_amount, da_amount, attachments) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('iiiis', $application_id, $registration_amount, $ta_amount, $da_amount, $attachments_path);

    if ($stmt->execute()) {
        echo "<script> alert('hehe');</script>";
        $stmt->close();
        $conn->close();
        header("Location: Reimbursement_page4.php?id=$application_id");
        exit;
    } else {
        die($stmt->error);
    }
}
else if (isset($_GET['approved_application'])) {
    $application_id = $_GET['approved_application'];

    $sql = "SELECT * FROM applications WHERE application_id = $application_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "No records found for Employee ID: $e_id";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reimbursement Form</title>
    <link rel="stylesheet" href="Reimbursement_page3.css">
</head>

<body>
    <div class="card">
        <form id="signUpForm" action="Reimbursement_page3.php" method="POST" onsubmit="return validateForm();" enctype="multipart/form-data">
            <input type="hidden" name="application_id" value="<?php echo $application_id; ?>">
            <label id="lab">Details to be filled for claiming reimbursement</label><br><br>
            <div class="form-group">
                <label for="name">Name and address of organizing Institution of <?php echo $row['purpose']; ?>:<span class="asterisk">*</span></label>
                <input type="text" name="name" id="auto" placeholder="Enter Name and Address" value="<?php echo $row['org_institution']; ?>" required readonly>
            </div>
            <div class="form-group">
                <label for="program_duration">Date and Duration of program attended from:<span class="asterisk">*</span></label>
                <input type="date" name="start_date" id="auto" value="<?php echo $row['duration_from']; ?>" required readonly>
                to
                <input type="date" name="end_date" id="auto" value="<?php echo $row['duration_to']; ?>" required readonly>
            </div>
            <div class="form-group">
                <label for="total_days">Total number of days:<span class="asterisk">*</span></label>
                <input type="number" name="total_days" id="auto" placeholder="Enter total days" value="<?php echo $row['total_days']; ?>" readonly required>
            </div>
            <div class="form-group">
                <label for="vacation_period">The program is during Vacation/non-vacation period:<span class="asterisk">*</span></label>
                <input type="text" name="vacation_period" id="auto" placeholder="Select period" value="<?php echo $row['vacation_period']; ?>" readonly required>
                <!-- <select name="vacation_period" id="vacation_period" required readonly>
                    <option value="" disabled selected>Select period</option>
                    <option value="vacation">Vacation</option>
                    <option value="non_vacation">Non-vacation</option>
                </select> -->
            </div>
            <div class="form-group">
                <label for="od_days">No. of days OD was sanctioned:<span class="asterisk">*</span></label>
                <input type="number" name="od_days" id="auto" placeholder="Enter number of days" value="<?php echo $row['od_sanctioned']; ?>" required min="0" readonly>
            </div>
            <div class="form-group">
                <label for="registration_amount">Amount paid for registration: ₹<span class="asterisk">*</span></label>
                <input type="number" name="registration_amount" id="registration_amount" placeholder="Enter amount" required min="0">
            </div>
            <div class="form-group">
                <label for="ta_amount">TA: ₹<span class="asterisk">*</span></label>
                <input type="number" name="ta_amount" id="ta_amount" placeholder="Enter amount" required min="0">
            </div>
            <div class="form-group">
                <label for="da_amount">DA: ₹<span class="asterisk">*</span></label>
                <input type="number" name="da_amount" id="da_amount" placeholder="Enter amount" required min="0">
            </div>
            <div class="form-group">    
                <label for="sanctioned_amount">Amount sanctioned: ₹<span class="asterisk">*</span></label>
                <input type="number" name="sanctioned_amount" id="auto" placeholder="Enter amount" value="<?php echo $row['amount_sanctioned']; ?>" required min="0" readonly>
            </div>
            <div class="form-group">
                <label for="attachments">*Attach original receipt and xerox copy of certificate/attendance certificate if any:<span class="asterisk">*</span></label>
                <input type="file" name="attachments" id="attachments" multiple required>
            </div>
            <h5>Check above details & click next to proceed further</h5>
            <input type="submit" id="button" value="Next">
        </form>
    </div>
</body>
<script src="Reimbursement_page3.js"></script>

</html>