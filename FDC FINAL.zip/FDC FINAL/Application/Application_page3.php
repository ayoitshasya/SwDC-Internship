<?php
session_start();

function uploadFile($input_name, $application_id)
{
    $file_name = $_FILES[$input_name]["name"];
    $file_tmp = $_FILES[$input_name]["tmp_name"];

    //renaming file uniquely for each user
    $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
    $upload_file = 'PK_' . $application_id . '_' . $input_name . '.' . $file_extension;
    $upload_dir = "../uploads/Applications/";

    // Move uploaded file to desired location
    if (move_uploaded_file($file_tmp, $upload_dir . $upload_file)) {
        return '../uploads/Applications/' . $upload_file;
    }
    return NULL;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Collect form 2 data from POST
    $amount_claimed = $_POST['amount_claimed'];
    $year = $_POST['year'];
    $total_ods = $_POST['total_ods'];
    $od_year = $_POST['od_year'];
    $purpose_scope = $_POST['purpose_scope'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO applications 
    (eid, purpose, org_institution, supporting_org, duration_from, duration_to, total_days, registration_last_day, 
    registration_fee, vacation_period, ods_required, amount_claimed, year, total_ods, od_year, purpose_scope, status) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $pending = 'Pending';
    $stmt->bind_param("isssssisisiiiiiss", $_SESSION["eid"], $_SESSION["purpose"], $_SESSION["org_institution"], $_SESSION["supporting_org"], $_SESSION["duration_from"], $_SESSION["duration_to"], $_SESSION["total_days"], $_SESSION["registration_last_day"], $_SESSION["registration_fee"], $_SESSION["vacation_period"], $_SESSION["ods_required"], $amount_claimed, $year, $total_ods, $od_year, $purpose_scope, $pending);

    if ($stmt->execute()) {
        // Retrieve the auto-incremented application_id
        $application_id = $stmt->insert_id;

        // Upload files with the application_id
        $load_adjustment_path = uploadFile('load_adjustment', $application_id);
        $conference_brochure_path = uploadFile('conference_brochure', $application_id);
        $email_upload_path = uploadFile('email_upload', $application_id);

        // Update the application record with the file paths
        $sql = "UPDATE applications SET 
            load_adjustment_path = ?, conference_brochure_path = ?, email_upload_path = ? 
            WHERE application_id = ?";
        $update_stmt = $conn->prepare($sql);
        $update_stmt->bind_param(
            "sssi",
            $load_adjustment_path,
            $conference_brochure_path,
            $email_upload_path,
            $application_id
        );
        $update_stmt->execute();
        $update_stmt->close();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
    $conn->close();
    header("location: Application_page4(pdf).php?id=$application_id");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FDC Application</title>
    <link rel="stylesheet" href="Application_page3.css">
</head>

<body>
    <div class="card">
        <form id="signUpForm" action="Application_page3.php" method="post" onsubmit="return validateForm()" enctype="multipart/form-data">
            <label id="lab">Details of FDC Facility availed if any</label><br><br>
            <div class="form-group">
                <label for="amount_claimed">Amount claimed for year 20:<span class="asterisk">*</span></label>
                <input type="text" name="amount_claimed" id="amount_claimed" placeholder="auto-generated" required>
                <input type="number" name="year" id="year" placeholder="auto-generated" required style="margin-left: 10px;">
            </div>
            <div class="form-group">
                <label for="total_ods">Total ODs availed for the year 20:<span class="asterisk">*</span></label>
                <input type="number" name="total_ods" id="total_ods" placeholder="auto-generated" required>
                <input type="number" name="od_year" id="od_year" placeholder="auto-generated" required style="margin-left: 10px;">
            </div>
            <a href="https://drive.google.com/file/d/1aWy9DpXKEWiG_bDdsY--IpdXvrJoGk8E/view?usp=drive_link" target="_blank" class="download-link">Link to download the format</a>
            <div class="form-group">
                <label for="load_adjustment">Upload Load adjustment sheet (.pdf, .docx, .doc):<span class="asterisk">*</span></label>
                <input type="file" name="load_adjustment" id="load_adjustment" accept=".pdf,.docx,.doc" required>
                <div class="error-message" id="load_adjustment_error"></div>
            </div>
            <div class="form-group">
                <label for="conference_brochure">Upload Conference brochure (.pdf, .docx, .doc):<span class="asterisk">*</span></label>
                <input type="file" name="conference_brochure" id="conference_brochure" accept=".pdf,.docx,.doc" required>
                <div class="error-message" id="conference_brochure_error"></div>
            </div>
            <div class="form-group">
                <label for="email_upload">Upload email (jpeg, jpg, png, .pdf, .docx): <span style="font-size: 0.8em;">(upload email if high authority has mailed)</span></label>
                <input type="file" name="email_upload" id="email_upload" accept="image/jpeg,image/jpg,image/png,.pdf,.docx">
                <div class="error-message" id="email_upload_error"></div>
            </div>
            <div class="form-group">
                <label for="purpose_scope">Purpose/scope for attending the STTP/Symposium/workshop/conference/seminar:<span class="asterisk">*</span></label>
                <textarea name="purpose_scope" id="purpose_scope" rows="4" placeholder="Enter the purpose/scope" required></textarea>
            </div>

            <h5>Check above details & click next to proceed further</h5>
            <input type="submit" id="button" value="Next">
        </form>
    </div>
    <script src="Application_page3.js"></script>
</body>

</html>