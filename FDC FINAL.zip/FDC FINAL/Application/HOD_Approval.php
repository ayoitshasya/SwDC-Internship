<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



$application_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recommendation = $_POST['recommendation'];
    $reason = $_POST['reason'];
    $application_id = $_POST['application_id'];
    if ($recommendation == 'Recommended') {
        $status = "Recommended by HOD";
    } else {
        $status = "Rejected by HOD";
    }
    $sql = "UPDATE applications SET HOD_recommendation = '$recommendation', HOD_reason = '$reason', status = '$status' WHERE application_id = $application_id";
    $result = $conn->query($sql);
    if ($result) {
        echo "<script> alert('Updated successfully'); </script>";
        header("location: View_applications.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FDC Application - HOD </title>
    <link rel="stylesheet" href="HOD_Approval.css">
    <script src="HOD_Approval.js" defer></script>
</head>

<body>
    <div class="card">
        <form id="signUpForm" action="HOD_Approval.php" method="POST">
            <input type="hidden" name="application_id" value="<?php echo $application_id; ?>">
            <label id="lab">Recommendation from HOD</label><br><br>
            <div class="form-group">
                <label for="recommendation">Recommended/Non-Recommended:<span class="asterisk">*</span></label>
                <select name="recommendation" id="recommendation" required>
                    <option value="Recommended">Recommended</option>
                    <option value="Non-Recommended">Non-Recommended</option>
                </select>
            </div>
            <div class="form-group">
                <input type="checkbox" name="load_adjustment_checked" id="load_adjustment_checked" required>
                <label for="load_adjustment_checked">I have checked load adjustment form</label>
                <div class="error-message" id="load_adjustment_error"></div>
            </div>
            <div class="form-group">
                <input type="checkbox" name="brochure_checked" id="brochure_checked" required>
                <label for="brochure_checked">I have checked brochure</label>
                <div class="error-message" id="brochure_error"></div>
            </div>
            <div class="form-group">
                <label for="reason">Reason for recommendation/Non-Recommendation:<span class="asterisk">*</span></label>
                <textarea name="reason" id="reason" rows="4" placeholder="Enter the reason" required></textarea>
            </div>

            <h5>Check above details & click next to proceed further</h5>
            <input type="submit" id="button" value="Submit">
        </form>
    </div>
</body>

</html>