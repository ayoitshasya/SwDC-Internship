function validateForm() {
    const requiredFields = document.querySelectorAll('.form-group input, .form-group select');
    let allFilled = true;
    requiredFields.forEach(field => {
        if (!field.value) {
            allFilled = false;
            field.style.border = '1px solid red';
        } else {
            field.style.border = '1px solid #a52017';
        }
    });
    if (allFilled) {
        window.location.href = 'Reimbursement_page2.html';
    } else {
        alert('Please fill all the required fields.');
    }
}
