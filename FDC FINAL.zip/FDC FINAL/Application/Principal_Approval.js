function validateForm() {
    const requiredFields = document.querySelectorAll('.form-group input[required], .form-group textarea[required]');
    let allFilled = true;
    
    requiredFields.forEach(field => {
        if (!field.value || (field.type === 'number' && field.value < 0)) {
            allFilled = false;
            field.style.border = '1px solid red';
        } else {
            field.style.border = '1px solid #a52017';
        }
    });
    
    if (allFilled) {
        alert('Form submitted successfully.');
        return true;
    } else {
        alert('Please fill all the required fields and ensure no negative values.');
        return false;
    }
}

// document.getElementById('button').addEventListener('click', validateForm);
