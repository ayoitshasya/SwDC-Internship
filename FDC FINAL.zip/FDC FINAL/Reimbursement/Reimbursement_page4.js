function validateForm() {
    const requiredFields = document.querySelectorAll('.form-group input, .form-group select');
    let allFilled = true;
    requiredFields.forEach(field => {
        if (!field.value) {
            allFilled = false;
            field.style.border = '1px solid red';
        } else {
            field.style.border = '1px solid #a52017';
        }
    });
    if (allFilled) {
        window.location.href = 'homeLoggedIn.php';
    } else {
        alert('Please fill all the required fields.');
    }
}

function populateYearSelect() {
    const startYear = 2000;
    const endYear = 2030;
    const yearSelectElements = document.querySelectorAll('.year-select');
    yearSelectElements.forEach(select => {
        for (let year = startYear; year <= endYear; year++) {
            const option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            select.appendChild(option);
        }
    });
}

window.onload = populateYearSelect;