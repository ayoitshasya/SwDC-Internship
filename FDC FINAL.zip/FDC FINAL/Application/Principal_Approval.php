<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$application_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date_of_meeting = $_POST['date_of_meeting'];
    $final_recommendation = $_POST['final_recommendation'];
    $amount_sanctioned = $_POST['amount_sanctioned'];
    $designation = $_POST['designation'];
    $od_sanctioned = $_POST['od_sanctioned'];
    $application_id = $_POST['application_id'];

    
    $sql = "UPDATE applications SET date_of_meeting = '$date_of_meeting', final_recommendation = '$final_recommendation', amount_sanctioned = $amount_sanctioned, designation = '$designation', od_sanctioned = $od_sanctioned, status = 'Approved by Principal'  WHERE application_id = $application_id";
    $result = $conn->query($sql);
    if ($result) {
        header("location: View_applications.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FDC Application - PRINCIPAL</title>
    <link rel="stylesheet" href="Principal_Approval.css">
</head>

<body>
    <div class="card">
        <label id="lab">FDC Approval</label><br><br>
        <form action="Principal_Approval.php" method="post" onsubmit="return validateForm();">
            <input type="hidden" name="application_id" value="<?php echo $application_id; ?>">
            <div class="form-group">
                <label for="date_of_meeting">Date of meeting for approval of committee:<span class="asterisk">*</span></label>
                <input type="date" name="date_of_meeting" id="date_of_meeting" required>
            </div>
            <div class="form-group">
                <label for="final_recommendation">Final recommendation/Remark at committee:<span class="asterisk">*</span></label>
                <textarea name="final_recommendation" id="final_recommendation" rows="4" placeholder="Enter the final recommendation or remark" required></textarea>
            </div>
            <div class="form-group">
                <label for="amount_sanctioned">Amount sanctioned in ₹:<span class="asterisk">*</span></label>
                <input type="number" name="amount_sanctioned" id="amount_sanctioned" placeholder="Enter the amount sanctioned" required min="0">
            </div>
            <div class="form-group">
                <label for="designation">Designation:<span class="asterisk">*</span></label>
                <input type="text" name="designation" id="designation" placeholder="Enter your Designation" required>
            </div>
            <div class="form-group">
                <label for="od_sanctioned">No. of OD sanctioned:<span class="asterisk">*</span></label>
                <input type="number" name="od_sanctioned" id="od_sanctioned" placeholder="Enter the number of ODs sanctioned" required min="0">
            </div>
            <input type="submit" name="submit" id="button" value="Submit">
        </form>
        <script src="Principal_Approval.js" defer></script>
    </div>
</body>

</html>