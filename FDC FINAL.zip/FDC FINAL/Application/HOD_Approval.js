function validateForm() {
    const loadAdjustmentChecked = document.getElementById('load_adjustment_checked').checked;
    const brochureChecked = document.getElementById('brochure_checked').checked;
    
    let allFilled = true;

    if (!loadAdjustmentChecked) {
        allFilled = false;
        document.getElementById('load_adjustment_error').textContent = 'Please check this box to proceed.';
    } else {
        document.getElementById('load_adjustment_error').textContent = '';
    }

    if (!brochureChecked) {
        allFilled = false;
        document.getElementById('brochure_error').textContent = 'Please check this box to proceed.';
    } else {
        document.getElementById('brochure_error').textContent = '';
    }

    const recommendation = document.getElementById('recommendation').value;
    const reason = document.getElementById('reason').value;

    if (recommendation === '' || reason === '') {
        allFilled = false;
        alert('Please fill all the required fields.');
    }
    if (allFilled) {
        window.location.href = 'Application_page2.html';
    }
}
document.getElementById('button').addEventListener('click', validateForm);
